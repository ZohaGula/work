	<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/style.css">
		<style>
			table, th, td {
				    border-collapse: collapse;

}
		table th{
				width:100%;
				background: #d10303;
				color: white;
				font-weight: bold;
				border-bottom: red outset 2px;
			}
			table td{
				background: #333;
				border-bottom: white outset 2px;
				color : white;
			}
			@media (max-width: 736px) {
			table, th, td {
    border: 1px solid red;
}
		table th{
				background: #d10303;
				color: white;
				font-weight: bold;
				border-bottom: white outset 2px;
			}
		</style>
	</head>
</html>
	<?php
	$u_name   = htmlspecialchars($_POST['name']);
	$userIP    = htmlspecialchars($_POST['userIP']);
	$subject    = htmlspecialchars($_POST['subject']);
	$emailAddress   = htmlspecialchars($_POST['email']);
    $txtmessage     = htmlspecialchars($_POST['message']);

    $to      = '';
    $subject = '[AZU Clinic Email]';
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'To: Zoha <zohagul007@gmail.com>'. "\r\n";
    $headers .= 'From: AZU CLICNIC  <support@azuclinic.com>' . "\r\n" .
        'Reply-To: support@azuclinic.com' . "\r\n" .  'X-Mailer: PHP/' . phpversion();
    $message  = '<br><br>';
$message.='<p style="text-align:center; color:#d10303">Hello <strong>AL-OMIE,</strong> <br>'.$u_name.' have contacted you , Here\'s detail below. </p>';
    $message .= '<table cellspacing="0" cellpadding="8" class="table bordered" style="width:100%; margin :auto;" border="1" border-color="gray">';
	$message .= '<tr><th style="background-color:#d10303;">User Name : </th> <td style="background: dimgray;width=100%">'. $u_name .'</td></tr>';    
	$message .= '<tr><th style="background-color:#d10303;">Email Address : </th> <td style="background: dimgray;width=100%"">'. ((strlen($emailAddress) > 0) ? $emailAddress : "Not provided") .'</td></tr>';
	$message .= '<tr><th  style="background-color:#d10303;">User IP : </th> <td style="background: dimgray;width=100%">'. $userIP .'</td></tr>';
	$message .= '<tr><th style="background-color:#d10303;">Subject : </th> <td style="background: dimgray;width=100%">'. $subject .'</td></tr>';    	
    $message .= '<tr><th style="background-color:#d10303;">Message : </th> <td style="background: dimgray;width=100%">'. $txtmessage .'</td></tr>';    
    $message .= '</table>';   
    mail($to, $subject, $message, $headers);
	$response_msg = array ("status"=>true);

    echo json_encode($response_msg);
?> 