var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'zohagul007@gmail.com',
      pass: 'zohagul@007'
    }
  });
  
  var mailOptions = {
    from: 'zohagul007@gmail.com',
    to: 'zainiir0311@gmail.com',
    subject: 'Sending Email using Node.js',
    html: '<h1>Welcome</h1><p>Email Send hogiyaa NODEjs seee.</p>'
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });