(function ($) {
  "use strict"; $(document).ready(function () {
    jQuery("#load").fadeOut(); jQuery("#loading").delay(0).fadeOut("slow");
    $(".navbar a").on("click", function (event) { if (!$(event.target).closest(".nav-item.dropdown").length) { $(".navbar-collapse").collapse('hide'); } }); $('#back-to-top').fadeOut();
    $(window).on("scroll", function () {
      if ($(this).scrollTop() > 250) {
        $('#back-to-top').fadeIn(1400);
      }
      else { $('#back-to-top').fadeOut(400); }
    }); $('#top').on('click', function () {
      $('top').tooltip('hide');
      $('body,html').animate({ scrollTop: 0 }, 800); return false;
    }); $(function () { $('[data-toggle="tooltip"]').tooltip() });
    $('.iq-accordion .iq-ad-block .ad-details').hide();
    $('.iq-accordion .iq-ad-block:first').addClass('ad-active').children().slideDown('slow');
    $('.iq-accordion .iq-ad-block').on("click", function () {
      if ($(this).children('div').is(':hidden')) {
        $('.iq-accordion .iq-ad-block').removeClass('ad-active').children('div').slideUp('slow');
        $(this).toggleClass('ad-active').children('div').slideDown('slow');
      }
    });
    $('.navbar-nav li a').on('click', function (e) {
      var anchor = $(this);
      $('html, body').stop().animate({ scrollTop: $(anchor.attr('href')).offset().top - 0 }, 1500);
      e.preventDefault();
    }); $(window).on('scroll', function () {
      if ($(this).scrollTop() > 100) {
        $('header').addClass('menu-sticky');
      } else {
        $('header').removeClass('menu-sticky');
      }
    });
    $('.popup-gallery').magnificPopup({
      delegate: 'a.popup-img', type: 'image', tLoading: 'Loading image #%curr%...', mainClass: 'mfp-img-mobile', gallery: {
        enabled: true, navigateByImgClick: true, preload: [0, 1]
      }, image: {
        tError: '<a href="%url%">The image #%curr%</a> could not be loaded.', titleSrc: function (item) {
          return item.el.attr('title') + '<small>by Marsel Van Oosten</small>';
        }
      }
    });
    $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({ disableOn: 700, type: 'iframe', mainClass: 'mfp-fade', removalDelay: 160, preloader: false, fixedContentPos: false });
    $('#countdown').countdown({ date: '10/01/2019 23:59:59', day: 'Day', days: 'Days' });
    $('.timer').countTo();
    $('.owl-carousel').each(function () {
      var $carousel = $(this);
      $carousel.owlCarousel({ items: $carousel.data("items"), loop: $carousel.data("loop"), margin: $carousel.data("margin"), nav: $carousel.data("nav"), dots: $carousel.data("dots"), autoplay: $carousel.data("autoplay"), autoplayTimeout: $carousel.data("autoplay-timeout"), navText: ['<i class="fa fa-angle-left fa-2x"></i>', '<i class="fa fa-angle-right fa-2x"></i>'], responsiveClass: true, responsive: { 0: { items: $carousel.data("items-mobile-sm") }, 480: { items: $carousel.data("items-mobile") }, 786: { items: $carousel.data("items-tab") }, 1023: { items: $carousel.data("items-laptop") }, 1199: { items: $carousel.data("items") } } });
    }); 
    var wow = new WOW({ boxClass: 'wow', animateClass: 'animated', offset: 0, mobile: false, live: true });
     wow.init();
  }); 
  
})(jQuery);
var shoppingCart = (function () {
  // =============================
  // Private methods and propeties
  // =============================
  cart = [];

  // Constructor
  function Item(name, price, count) {
    this.name = name;
    this.price = price;
    this.count = count;
  }
  function saveCart() {
    localStorage.setItem('shoppingCart', JSON.stringify(cart));
  }
  function loadCart() {
    cart = JSON.parse(localStorage.getItem('shoppingCart'));
  }
  if(localStorage.getItem("shoppingCart") != null) {
    loadCart();
  }
  var obj = {};
  // Add to cart
  obj.addItemToCart = function (name, price, count) {
    for (var item in cart) {
      if (cart[item].name === name) {
        cart[item].count++;
        saveCart();
        return;
      }
    }
    var item = new Item(name, price, count);
    cart.push(item);
    saveCart();
  }
  // Set count from item
  obj.setCountForItem = function (name, count) {
    for (var i in cart) {
      if (cart[i].name === name) {
        cart[i].count = count;
        break;
      }
    }
  };
  // Remove item from cart
  obj.removeItemFromCart = function (name) {
    for (var item in cart) {
      if (cart[item].name === name) {
        cart[item].count--;
        if (cart[item].count === 0) {
          cart.splice(item, 1);
        }
        break;
      }
    }
    saveCart();
  }
  // Remove all items from cart
  obj.removeItemFromCartAll = function (name) {
    for (var item in cart) {
      if (cart[item].name === name) {
        cart.splice(item, 1);
        break;
      }
    }
    saveCart();
  }
  // Clear cart
  obj.clearCart = function () {
    cart = [];
    saveCart();
  }

  // Count cart 
  obj.totalCount = function () {
    var totalCount = 0;
    for (var item in cart) {
      totalCount += cart[item].count;
    }
    return totalCount;
  }
  // Total cart
  obj.totalCart = function () {
    var totalCart = 0;
    for (var item in cart) {
      totalCart += cart[item].price * cart[item].count;
    }
    return Number(totalCart.toFixed(2));
  }
  // List cart
  obj.listCart = function () {
    var cartCopy = [];
    for (i in cart) {
      item = cart[i];
      itemCopy = {};
      for (p in item) {
        itemCopy[p] = item[p];
      }
      itemCopy.total = Number(item.price * item.count).toFixed(2);
      cartCopy.push(itemCopy);    
    }
    return cartCopy;
  }
  return obj;
})();
// Add item
$('.add-to-cart').click(function (event) {
  event.preventDefault();
  var name = $(this).data('name');
  var price = Number($(this).data('price'));
  shoppingCart.addItemToCart(name, price, 1);
  displayCart();
});
// Clear items
$('.clear-cart').click(function () {
  shoppingCart.clearCart();
  displayCart();
});
function displayCart() {
  var cartArray = shoppingCart.listCart();
  var output = "";
  for (var i in cartArray) {
    output += "<tr>"
      + "<td>" + cartArray[i].name + "</td>"
      + "<td>(" + cartArray[i].price + ")</td>"
      + "<td><div class='input-group'><button class='minus-item input-group-addon btn btn-primary btn-0' data-name=" + cartArray[i].name + ">-</button>"
      + "<input type='number' class='item-count form-control btn1' data-name='" + cartArray[i].name + "' value='" + cartArray[i].count + "'>"
      + "<button class='plus-item btn btn-success input-group-addon btn2' data-name=" + cartArray[i].name + ">+</button></td>"
      + "<td><button class='delete-item btn btn-danger btn3' data-name=" + cartArray[i].name + "><i class='fa fa-trash'></button></td>"
      + " = "
      +"</div>"
      + "</tr>";
  }
  $('.show-cart').html(output);
  $('.total-cart').html(shoppingCart.totalCart());
  $('.total-count').html(shoppingCart.totalCount());
  localStorage.setItem('Cart_total', JSON.stringify(shoppingCart.totalCart()));
}
// Delete item button
$('.show-cart').on("click", ".delete-item", function (event) {
  var name = $(this).data('name')
  shoppingCart.removeItemFromCartAll(name);
  displayCart();
})
// -1
$('.show-cart').on("click", ".minus-item", function (event) {
  var name = $(this).data('name')
  shoppingCart.removeItemFromCart(name);
  displayCart();
})
// +1
$('.show-cart').on("click", ".plus-item", function (event) {
  var name = $(this).data('name')
  shoppingCart.addItemToCart(name);
  displayCart();
})
// Item count input
$('.show-cart').on("change", ".item-count", function (event) {
  var name = $(this).data('name');
  var count = Number($(this).val());
  shoppingCart.setCountForItem(name, count);
  displayCart();
});
displayCart();
//PAYMENT FORM CODE
 document.getElementById("TotalPayment").value= " " + " MYR " + JSON.parse(localStorage.getItem('Cart_total'));

 //Payment-Page-Validation
//  $("#confirm").on("click", function () {

//   var validationsPassed = true;
//   var self = $(this);
//   var obj = {
//     fulName: $("#fulName").val().trim(),
//     birthDate: $("#birthDate").val().trim(),
//     TotalPayment: $("#TotalPayment").val().trim(),
//     emailField: $("#emailField").val().trim(),
//     phone: $("#phone").val().trim(),
//     curreny: $("#curreny").val(),
//     address: $("#address").val().trim(),
//     //serviceName: $("#serviceName").val().trim(),
//     postalCode: $("#postalCode").val().trim(),
//     city: $("#city").val().trim(),
//     state: $("#state").val().trim(),
//     country: $("#country").val().trim(),
//     secret: $("#secret").val().trim(),
//   };

//   // var isValid = 0;
//   for (var keys in obj) {
//     if (!obj[keys]) {
//       var $el = $("#" + keys);
//       // $el.addClass("errField");
//       validationsPassed = false;
     
//     }
//   }
//   if (!validationsPassed) {
//     return;
//   }

//   if (!validateEmail(obj.emailField)) {
//     var $el = $("#emailField");
//     // $el.addClass("errField");
//     validationsPassed = false;
//     return;
//   }

//   var isAggree = $("#checkBox_isAggree").prop("checked");

//   if (!isAggree) {
//     var $el = $("#para_isAggree");
//     // $el.addClass("errField");
//     validationsPassed = false;
//     return;
//   }
//   var dataObj = $("#paymentForm").serializeArray();
//   self.attr("disabled", true);
//  $("#paymentForm").submit();
// });
