import React, {Component} from 'react';
import BannerImg from '../images/banner/We.png';
class Banner extends Component {
  render(){
  return (
   
    <div className="banner">
<div className="container-fluid">
<div className="row">
<div className="col-lg-6">
<div className="banner-text">
<h3 className="main-color mb-3">Welcome To</h3>
<h2 className="font-weight-bold  mb-3">Wesmartify Resources</h2>
<p className=" mb-4">We deliver top items and durable services in the global programming commercial center.</p>
        <p>	We don't do a considerable measure of things, however whatever we do,
                 we do it in style and as per the most elevated benchmarks of programming designing.</p>
<div className="align-items-center d-flex">
<a className="button" href="#">Read More</a>
<div className="play-video iq-asked-img">
<a href="video/01.mp4" className="iq-video popup-youtube"><i className="ion-ios-play-outline"></i></a>
</div>
</div>
</div>
</div>
<div className="col-lg-6">
<div className="banner-type wow fadeInRight">
<img className="img-fluid banner-person img-responsive" src={BannerImg} alt="Banner image" width="90%" />
</div>
</div>
</div>
</div>
</div>
    
  );
}
}
export default Banner;
