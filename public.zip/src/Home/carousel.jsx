import React, {Component} from 'react';


class App extends Component {
  render(){
  return (
    

    
  );
}
}
export default Carousel;
