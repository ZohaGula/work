import React, {Component} from 'react';
import serviceImg1 from '../images/feature/01.png'
import serviceImg2 from '../images/feature/01.png'
import serviceImg3 from '../images/feature/03.png'
import serviceImg4 from '../images/feature/04.png'
import serviceImg5 from '../images/feature/05.png'
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
class MainServices extends Component {
  render(){
      var btnStyle ={
          background : '#8b1932'
      }
  return (

    <section className="service-provide Service-shap pt-0 Service-shaps">
    <div className="container">
    <div className="row">
    <div className="col-sm-12">
    <div className="title-box ">
    <h2 className="title font-weight-bold">Services And Prices</h2>
    <p className="sub-title">An impressive design alone is not enough,
                    you need to provide a great experience to the user by offering the User-friendly design. </p>
    </div>
    </div>
    </div>
    <div className="row">
    <div className="col-lg-4 col-md-4">
    <div className="rplr-30">
    <div className="future-services services text-center wow slideInUp" data-wow-duration="0.5s">
    <div className="future-img">
    <img src={serviceImg1} className="img-fluid mb-4" />
    </div>
    <h4 className="mb-3">Custom Logo Design</h4>
    <p className="mb-0">At WESMARTIFY RESOURCES, we cover the entire spectrum of digital marketing, which 
            includes designing your unique & memorable company logo. 
            We build an unforgettable brand identity for your business </p>
            <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
            <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}> <FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
    </div>
    </div>
    </div>
    <div className="col-lg-4 col-md-4">
    <div className="rplr-30">
    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
    <div className="future-img">
    <img src={serviceImg2} className="img-fluid mb-4" />
    </div>
    <h4 >Mobile Application</h4>
    <p className="mb-0">We make delightful Apps which resonates with your brand!</p>
    <p>We recognize that every business is unique, hence we mold all our mobile application solution (Android or iOS) to fulfill your specific business needs.</p>
    <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
            <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}><FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
    </div>
    </div>
    </div>
    <div className="col-lg-4 col-md-4">
    <div className="rplr-30">
    <div className="future-services services text-center wow slideInUp" data-wow-duration="1.5s">
    <div className="future-img">
    <img src={serviceImg3} className="img-fluid mb-4" />
    </div>
    <h4 className="mb-3"> Business Card Design</h4>
    <p> To make the best possible impression on the people you meet, your custom business card should be 
                    so unique.Our team create professional business card that stands out in crowd, reflects your corporate.</p>
                    <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                    <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}> <FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
            </div>
    </div>
    </div>
    <div className="col-lg-4 col-md-4">
    <div className="rplr-30">
    <div className="future-services services text-center wow slideInUp" data-wow-duration="0.5s">
    <div className="future-img">
    <img src={serviceImg4} className="img-fluid mb-4"/>
    </div>
    <h4 className="mb-3">Software Development.</h4>
    <p><strong>WESMARTIFY RESOURCES</strong> offers full-scale software development services in various application development environments. 
                     Our expertise is developing client server application under Visual Basic ,PHP and MySQL environment.</p>
                     <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                     <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}> <FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
                    </div>
    </div>
    </div>
    <div className="col-lg-4 col-md-4">
    <div className="rplr-30">
    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
    <div className="future-img">
    <img src={serviceImg5} className="img-fluid mb-4" />
    </div>
    <h4 className="mb-3">Web Design & Development</h4>
    <p><strong>WESMARTIFY RESOURCES</strong>
     makes sure your website accurately reflects the qualities of your brand. It's essential that a 
            website has 
            clean & responsive layout, because positive reaction to website creates the business potential.</p>
            <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
            <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}> <FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
           
    </div>
    </div>
    </div>
    <div className="col-lg-4 col-md-4 tricks-shaps">
                    <div className="rplr-30">
                    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
                    <div className="future-img">
                    <img src={serviceImg5} className="img-fluid mb-4" />
                    </div>
                    <h4 className="mb-3">Web Application</h4>
                    <p>Full Developers and Designers at <strong>WESMARTIFY RESOURCES</strong> have vast experience in both front-end and back-end delivering such high performance web applications of different plateforms to businesses across the globe.</p>
                    <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                    <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}> <FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>        
            </div>
                    </div>
                    </div>
                    <div className="col-lg-4 col-md-4">
                                    <div className="rplr-30">
                                    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
                                    <div className="future-img">
                                    <img src={serviceImg1} className="img-fluid mb-4" />
                                    </div>
                                    <h4 className="mb-3">Graphic Design</h4>
                                    <p>One stop destination for all of your graphic design needs. We
                                                    offer you a full service for Banners Designing, Visiting Card and also Unique Logo Design that resonates with your brand.</p>
                                                    <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                                                    <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}><FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
                                            </div>
                                    </div>
                                    </div>
                                    <div className="col-lg-4 col-md-4">
                                                    <div className="rplr-30">
                                                    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
                                                    <div className="future-img">
                                                    <img src={serviceImg2} className="img-fluid mb-4" />
                                                    </div>
                                                    <h4 className="mb-3">Website Maintenance</h4>
                                                    <p> We're specialized in
                                                                    Web Design Services, Website Redesign, Website Maintenance etc in reasonable prices.
                                                                We assist small, medium and large companies in building their professional web presence.</p>
                                                                <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                                                                <button className="btn btn-danger mt-3 " href="services.html" style={{background:"#8b1932"}}><FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
                                                            </div>
                                                    </div>
                                                    </div>
                                                    <div className="col-lg-4 col-md-4">
                                                                    <div className="rplr-30">
                                                                    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
                                                                    <div className="future-img">
                                                                    <img src={serviceImg4} className="img-fluid mb-4" />
                                                                    </div>
                                                                    <h4 className="mb-3">Wordpress Development</h4>
                                                                    <p> Creating the effective WordPress themes and plugins, 
                                                                                    converting PSD to WordPress or converting HTML site to WordPress, 
                                                                                    needs expertise related to WordPress. 
                                                                                   that attracts your customers allowing your website to be hit by a large number
                                                                                     of clicks.  </p>
                                                                                     <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
            <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}><FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
                                                                    </div>
                                                                    </div>
                                                                    </div>
                                                                    <div className="col-lg-4 col-md-4 tricks-shapes">
                                                                                    <div className="rplr-30">
                                                                                    <div className="future-services services text-center wow slideInUp" data-wow-duration="1s">
                                                                                    <div className="future-img">
                                                                                    <img src={serviceImg1} className="img-fluid mb-4" />
                                                                                    </div>
                                                                                    <h4 className="mb-3">Video Editor Animation</h4>
                                                                                    <p className="mb-0">Our Well Defined Animation Process Ensures Your Project Completion with satisfaction and promptly!</p>
                                                                                    <ul className="navbar">
                                                                                                    <li><i className="fa fa-hand-o-right"></i>  Story Board.</li>
                                                                                                    <li><i className="fa fa-hand-o-right"></i>  Animation.</li>
                                                                                                    <li><i className="fa fa-hand-o-right"></i>  Voice Over.</li>
                                                                                                    <li><i className="fa fa-hand-o-right"></i>  Final Video.</li>
                                                                                                    <li><i className="fa fa-hand-o-right"></i>  Concept Scripting.</li>
                                                                                                    </ul>
                                                                                                    <button className="mt-3 btn btn-danger " style={btnStyle} href="services.html">Read More</button>
                                                                                                    <button className="btn btn-danger mt-3 " href="services.html" style={btnStyle}><FontAwesomeIcon icon={faShoppingCart} /> Order for $499 </button>
                                                                            </div>
                                                                                    </div>
                                                                                    </div>
    </div>
    </div>
    </section>
  );
}
}
export default MainServices;
