import React, {Component} from 'react';
import ContentImg1 from '../images/feature/01.png'
import ContentImg2 from '../images/feature/01.png'
import ContentImg3 from '../images/feature/03.png'
import ContentImg4 from '../images/feature/04.png'
import ContentImg5 from '../images/feature/05.png'

class MainContent extends Component{
    render(){
        var divStyle ={
            visibility :"visible",
            animation: "fadeInUp"
                  } 
        return(
         
                <div className="main-content">
<section className="how-it-works conection-shap">
<div className="container">
<div className="row">
<div className="col-lg-4 col-md-4">
<div className="future-services text-center wow slideInUp" data-wow-duration="0.5s">
<div className="future-img">
<img src={ContentImg1} className="img-fluid mb-4" />
</div>
<h5 className="mb-3">Competitive Rates</h5>
<p className="mb-0">Shopping quotes for your next website project or looking to hire an expert?
         Make sure you get a quote from us! We're known for competitive rates and aggressive project quotes.</p>
</div>
</div>
<div className="col-lg-4 col-md-4">
<div className="future-services text-center wow slideInUp" data-wow-duration="1s">
<div className="future-img">
<img src={ContentImg2} className="img-fluid mb-4" />
</div>
<h5 className="mb-3">Reliable & Rapid Delivery</h5>
<p className="mb-0">Using agile methodology, always keeping you in the loop. Streamlined delivery, cost effective projects, designed to match your goals, timeline and budget.</p>
</div>
</div>
<div className="col-lg-4 col-md-4">
<div className="future-services text-center wow slideInUp" data-wow-duration="1.5s">
<div className="future-img">
<img src={ContentImg3} className="img-fluid mb-4" />
</div>
<h5 className="mb-3">Customer Satisfaction</h5>
<p className="mb-0">Dedicated account manager, project manager and consistent delivery team provided. We survey all of our clients, the results of which go directly to our CEO.</p>
</div>
</div>
</div>
</div>
</section>
<section className="pt-0 finding-shap">
<div className="container">
<div className="row">
<div className="col-md-6">
<div className="fully-dedicated wow slideInLeft">
<img src={ContentImg4} className="img-fluid " />
</div>
</div>
<div className="col-md-6 text-left align-self-center">
<div className="ml-3 mt-3">
<h3 className="font-weight-bold">ABOUT WESMARTIFY RESOURCES</h3>
<p className="mt-3"><strong> WESMARTIFY RESOURCES</strong> has been providing technology solutions to solve specific business problems. 
        We specialize in providing customized solutions to our customers based on their specific business needs.
         We have specialized team having expertise in Web Applications development and business 
        software solutions such as CRM, ERP, HRM, Accounting solutions etc. </p>
        <p><strong>We boost your business through our ready software solutions.</strong></p>
<a className="button mt-3" href="services.html">Get Started</a>
</div>
</div>
</div>
</div>
</section>

<section className="main-bg counter">
<div className="container">
<div className="row iq-counter3 text-center">
<div className="col-lg-3 col-md-6 col-sm-12">
<div className="iq-counter iq-pt-30 iq-rmb-30">
<span className="timer text-white" data-to="575" data-speed="5000">575</span>
<h6 className="mt-3 text-white">Increase in Leads</h6>
</div>
</div>
<div className="col-lg-3 col-md-6 col-sm-12">
<div className="iq-counter iq-pt-30 iq-rmb-30">
<span className="timer text-white" data-to="1540" data-speed="5000">1540</span>
<h6 className="mt-3 text-white">Lift in ROI</h6>
</div>
</div>
<div className="col-lg-3 col-md-6 col-sm-12">
<div className="iq-counter iq-pt-30 iq-rmb-30">
<span className="timer text-white" data-to="110" data-speed="5000">110</span>
<h6 className="mt-3 text-white">Increase in Conversions</h6>
</div>
</div>
<div className="col-lg-3 col-md-6 col-sm-12">
<div className="iq-counter iq-pt-30">
<span className="timer text-white" data-to="90" data-speed="5000">110</span>
<h6 className="mt-3 text-white">Decrease in ECPA</h6>
</div>
</div>
</div>
</div>
</section>
<section className="get-tips-tricks tricks-shap">
<div className="container">
<div className="row flex-row-reverse">
<div className="col-md-6">
<div className="tips-img wow fadeIn animated bounce slower">
<img src={ContentImg5} className="img-fluid"/>
</div>
</div>
<div className="col-md-6 text-left align-self-center">
<div className="ml-3 mt-3">
<h3 className="font-weight-bold">Our golden principles.</h3>
       
                        <div className="service-left wow fadeInUp animated" style={divStyle}>
                                <ul className="nav">
                                        <li><i className="fas fa-check-double"></i> Our golden principles have underpinned our aims and objectives. These are:</li>
                                        <li><i className="fas fa-check-double"></i> Quality is the prerequisite, and it is not optional</li>
                                        <li><i className="fas fa-check-double"></i> Your satisfaction is our satisfaction</li>
                                        <li><i className="fas fa-check-double"></i> Quality driven services at the affordable price</li>
                                        <li><i className="fas fa-check-double"></i> Being clear and transparent in all the matters</li>
                                        <li><i className="fas fa-check-double"></i> Designing an effective design is a process that needs the team work and the collaboration with our client</li>
                                </ul>
                        
                        </div>
                   
</div>
</div>
</div> </div></section>
</div>
           
        );
    }
    
}
export default MainContent;
