import React, {Component} from 'react';

import Banner  from './Banner';
import MainContent  from './mainContent';
import logo from '../images/logo.png'
import logoWhite from '../images/logo-white.png';
import MainServices from './MainServices';
import {faHome } from "@fortawesome/free-solid-svg-icons";
import {faGroup } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
class Head extends Component {
  render(){
  return (
  
   <header>
<div className="container-fluid main-header">
<div className="row">
<div className="col-sm-12">
<nav className="navbar navbar-expand-lg navbar-light">
<a className="navbar-brand" href="index.html">
<img src={logo} className="img-fluid logo" alt="logo" />
<img src={logoWhite} className="img-fluid logo-white" alt="logo-white" />
</a>
<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span className="navbar-toggler-icon"></span>
</button>
<div className="collapse navbar-collapse" id="navbarSupportedContent">
<ul className="navbar-nav ml-auto">
<li className="nav-item active">
<a className="nav-link" href="index.html">Home <FontAwesomeIcon icon={faHome} /> </a>
</li>
<li className="nav-item">
<a className="nav-link" href="about-us.html">About Us <FontAwesomeIcon icon={faGroup} /> </a>
</li>
<li className="nav-item dropdown">
    <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Pages 
    </a>
    <div className="dropdown-menu" aria-labelledby="navbarDropdown">
            <a className="dropdown-item" href="comingsoon.html">Website Development and Design</a>
    <a className="dropdown-item" href="blog-details.html">Wordpress Web Development</a>
    <a className="dropdown-item" href="404-error.html">Vide Editing and Animation</a>
    <a className="dropdown-item" href="comingsoon.html">Business Card Design</a>
    <a className="dropdown-item" href="comingsoon.html">Website Maintainence</a>
    <a className="dropdown-item" href="comingsoon.html">Mobile Application</a>
    <a className="dropdown-item" href="comingsoon.html">Graphics Design</a>
    <a className="dropdown-item" href="comingsoon.html">Custom Logo Design</a>
     </div>
    </li>
<li className="nav-item">
<a className="nav-link" href="services.html">Portfolio <i className="fa fa-camera"></i> </a>
</li>
<li className="nav-item">
<a className="nav-link" href="services.html">Process <i className="fa fa-refresh"></i> </a>
</li>
<li className="nav-item">
<a className="nav-link" href="contact.html">Contact Us <i className="fa fa-phone"></i> </a>
<Banner />
<MainContent />
<MainServices />
</li>
</ul>
</div>
</nav>
</div>
</div>
</div>
</header>

  );
}
}
export default Head;
