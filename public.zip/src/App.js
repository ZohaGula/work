import React, {Component} from 'react';

import Head from './Home/Header';

class App extends Component {
  render(){
  return (
    <div>
     
     <Head />
    </div>
  );
}
}
export default App;
