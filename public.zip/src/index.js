import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/css/bootstrap.css';
import './css/magnific-popup.css';
import './css/typography.css';
import './css/style.css';
import  './css/responsive.css'
import 'jquery/dist/jquery.min.js';
import 'jquery/dist/jquery.js';
import 'popper.js/dist/popper.js';
//import 'font-awesome/css/font-awesome.min.css'
//import './js/main.js';


ReactDOM.render(<App />, document.getElementById('root'));

