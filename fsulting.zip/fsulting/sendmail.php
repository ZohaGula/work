<html>
    <head><!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"></head>
</html>
	<?php

	$u_name   = htmlspecialchars($_POST['Name']);
	#$product    = htmlspecialchars($_POST['subject']);
	$userIP    = htmlspecialchars($_POST['userIP']);
    $txtmessage     = htmlspecialchars($_POST['Message']);
    $Phone    = htmlspecialchars($_POST['phone']);    
	$emailAddress   = htmlspecialchars($_POST['email']);
    $to      = '';
    $subject = '[AL-OMIE EMAIL]';
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'To: Al-OMIE <zohagul007@gmail.com>' . "\r\n";
    $headers .= 'From:AL-OMIE  <support@al-omie.com>' . "\r\n" .
        'Reply-To: support@al-omie.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    $message  = '<br><br>';
$message.='<p style="text-align:center; color:#d10303">Hello <strong>AL-OMIE,</strong> <br> '.'<strong>'.$u_name.'</strong>'.' have contacted you , Here\'s detail below. </p>';
    $message .= '<table cellspacing="0" cellpadding="8" class="table bordered" style="width:100%; margin :auto;" border="1" border-color="gray">';

   $message .= '<tr style="color:#fff;"><th style="background-color:#d10303;"> Subject : </th> <td style="background: dimgray; width=100%">'. $subject .'</td></tr>';
    $message .= '<tr style="color:#fff;"><th style="background-color:#d10303;">Email Address : </th> <td style="background: dimgray;width=100%"">'. ((strlen($emailAddress) > 0) ? $emailAddress : "Not provided") .'</td></tr>';
    $message .= '<tr style="color:#fff;"><th  style="background-color:#d10303;">User IP : </th> <td style="background: dimgray;width=100%">'. $userIP .'</td></tr>';
    $message .= '<tr style="color:#fff;"><th style="background-color:#d10303;">Phone : </th> <td style="background: dimgray;width=100%">'. $phone .'</td></tr>';
    $message .= '<tr style="color:#fff;"><th style="background-color:#d10303;">Message : </th> <td style="background: dimgray;width=100%">'. $txtmessage .'</td></tr>';    
    $message .= '</table>';

    mail($to, $subject, $message, $headers);
// 	$response_msg = array ("status"=>true);
	 echo '<div class="jumbotron text-center"><div class="alert alert-success">Email Sent Successfully</div>
	 <a href="index.php" class="btn btn-success">Go Back To Home </a>
	 </div>';
    //  echo json_encode($response_msg);
    
    
?> 