<?php

//fetch_data.php

include('database_connection.php');

if(isset($_POST["action"]))
{
	$query = "
		SELECT * FROM product WHERE product_status = '1'
	";
	if(isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"]))
	{
		$query .= "
		 AND product_price BETWEEN '".$_POST["minimum_price"]."' AND '".$_POST["maximum_price"]."'
		";
	}
	if(isset($_POST["brand"]))
	{
		$brand_filter = implode("','", $_POST["brand"]);
		$query .= "
		 AND product_brand IN('".$brand_filter."')
		";
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total_row = $statement->rowCount();
	$output = '';
	if($total_row > 0)
	{
		foreach($result as $row)
		{
			
			$output .= '
			<div class="col-md-4" style="margin-bottom:2% !important;">
                        <div class="card card-product">
                            <div class="card-image">
							<a href="#"> <img class="img" src="https://datasourceone.com/wp-content/uploads/2017/01/canada_business_email_database-275x275.jpg"> </a>
							</div>
							<div class="table">
							<h5>'. $row['product_brand'] .'</h5>
                            <div class="card-description"><p class="small">'. $row['product_name'] .'</p></div>
                                <div class="ftr">
                                    <div class="price">
                                         </div>
                                    <div class="stats">
									<input type="text" name="quantity" id="quantity' . $row["product_id"] .'" class="form-control" value="1" />
									<input type="hidden" name="hidden_name" id="name'.$row["product_id"].'" value="'.$row["product_name"].'" />
							<input type="hidden" name="hidden_price" id="price'.$row["product_id"].'" value="'.$row["product_price"].'" />
		<input type="button" name="add_to_cart" id="'.$row["product_id"].'" 
							style="margin-top:5px;" class="btn form-control add_to_cart mb-1 text-white" 
							value="Buy |  MYR '.$row['product_price'].'" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					</div>
			';
		}
	}
	else
	{
		$output = '<h3>No Data Found</h3>';
	}
	echo $output;
}

?>
