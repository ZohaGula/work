<?php 
include('database_connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Fsulting</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">
<!-- Stylesheets -->
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/plugins.css">
	<link rel="stylesheet" href="css/styles.css">
	<!-- Cusom css -->
	<link rel="stylesheet" href="../css/custom.css">
	<link rel="stylesheet" href="css/shop.css">
	<!-- Modernizer js -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>  
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://wesmartifyresources.com/plugins/bootstrap/bootstrap.min.css">
    <link href = "css/jquery-ui.css" rel = "stylesheet">
</head>
<body>
	<div class="fakeloader"></div>
	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">

		<!-- Header -->
		<header id="header" class="header sticky--header">

			<!-- Header Top Area -->
			<div class="header__top bg--blue">
				<div class="container">
					<div class="header__top__inner">
						<ul class="header__top__info">
							<li>
								<a href="#"><i class="fa fa-phone"></i>+60 18 956 5981</a>
							</li>
							<li>
								<a href="#">
									<i class="fa fa-envelope-o"></i> info@fsulting.com</a>
							</li>
						</ul>
						<div class="header__top__button">
							<a class="cr-btn cr-btn--lg" href="#">
								<span>Available  | Monday - Saturday</span>
							</a>
						</div>
					</div>
				</div>
			</div>
			<!--// Header Top Area -->
			<!-- Header Bottom Area -->
			<div class="header__bottom bg--white">
				<div class="container d-none d-lg-block">
					<div class="header__bottom__inner">
						<div class="header__logo">
							<a href="./">
								<img src="../images/logo/logo-theme.png" alt="header logo">
							</a>
						</div>
	<!-- Main Navigation -->
						<nav id="main-navigation" class="header__menu main-navigation">
							<ul>
								<li>
										<a href="index.html"> <i class="fa fa-home"> </i>&nbsp; HOME </a>
										</li>
								<li>
									<a href="about-us.html"> <i class="fa fa-info"> </i>&nbsp; Who We're  </a>
								</li>
								<li class="cr-dropdown">
									<a href="portfolio.html">Data</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="Data/Business-list/">Business List </a>
										</li>
										<li>
											<a href="portfolio.html">Residential Lists </a>
										</li>
										<li>
											<a href="portfolio.html">Email List </a>
										</li>
										<li>
											<a href="portfolio.html">Cell Phone List </a>
										</li>
									</ul>
								</li>
								<li>
									<a href="contact.html"> <i class="fa fa-phone"></i>&nbsp; CONTACT</a>
                                </li>
                                <li>
								<div>
                                <a id="cart-popover" class="btn" data-placement="bottom" title="Shopping Cart">
									<span class="fa fa-shopping-bag"></span>&nbsp;
									<span class="badge text-white bg-danger"></span>
									<span class="total_price">$ 0.00</span>
								</a>
                                </div>
							</li>
							</ul>
						</nav>
						<!--// Main Navigation -->

					</div>
				</div>
                <div id="popover_content_wrapper" style="display: none;">
				<span id="cart_details"></span>
				<div align="right">
					<a href="./" class="btn btn-success" id="continue" style="color:white;">
					<span class="fa fa-reply"></span> Continue Shopping
                    </a>
                    <a href="#" class="btn btn-primary text-white" id="check_out_cart" >
					 Check out
					</a>
					<a href="#" class="btn btn-default" id="clear_cart">
					<span class="fa fa-trash"></span> Clear
					</a>
				</div>
			</div>

			<div id="display_item">


			</div>
				<!-- Mobile Menu -->
				<div class="container d-block d-lg-none">
					<div class="mobile-menu clearfix d-md-block d-lg-none">
						<a class="mobile-logo" href="index.html">
							<img src="../images/logo/logo-theme.png" alt="logo">
						</a>
					</div>
				</div>
				<!-- //Mobile Menu -->
			</div>
			<!--// Header Bottom Area -->
		</header>
		<!-- //Header -->
     <!-- Breadcrumb Area -->
     <!-- Breadcrumb Area -->
        <div id="cr-breadcrumb-area" class="cr-breadcrumb-area bg-image--2 section-padding--md"
         data-overlay="8">
			<div class="container">
				<div class="cr-breadcrumb">
					<div class="cr-breadcrumb__left">
						<h2>About Us</h2>
						<p>What’s different about our company?
								We are the real deal – often copied, but never duplicated.</p>
					</div>
					<div class="cr-breadcrumb__right">
						<ul class="cr-breadcrumb__pagination">
							<li>
								<a href="../../">Home</a>
							</li>
							<li>About</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--// Breadcrumb Area -->
            
    <!-- Page Content -->
    <main class="page-content ">
        <!-- BLogs grid -->
                <div class="cr-section pg-blogs-area section-padding--xlg bg--white">
                    <div class="container">
                         <div class="row mb-3">
            <div class="col-md-3 " >                				
				<div class="list-group">
					<h3>Price</h3>
					<input type="hidden" id="hidden_minimum_price" value="0" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">1000 - 65000</p>
                    <div id="price_range"></div>
                </div>				
                <div class="list-group single-widget widget-recentpost">
                    <h3>Categories</h3>
                    <hr style="background:#00AC1F !important; height:1px">
					<?php
                    $query = "SELECT DISTINCT(product_brand) FROM product WHERE
                     product_status = '1' ORDER BY product_id DESC";
                    $statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    foreach($result as $row)
                    {
                    ?>
                 <div class="list-group-item checkbox form-control">
                        <label class="text-white">
                            <input type="checkbox" class=" common_selector brand" 
                            value="<?php echo $row['product_brand']; ?>"  > <?php echo $row['product_brand']; ?>
                        </label>
                    </div>
                    <?php
                    }
                    ?>
                </div>

				 </div>

            <div class="col-md-9 ">
            	
                <div class="filter_data">

                </div>
            </div>
        </div>

    </div>
    </div>

 
                <!-- Call To Action Area -->
                <section class="cta-area section-padding--md bg--grey--light bg--abstruct-mask">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-xl-9 col-lg-10">
                                <div class="calltoaction text-center">
                                    <h3>NEED HELP FOR YOUR <span class="color--theme">FINANCIAL CONSULTING ?</span>
                                    </h3>
                                    <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem
                                        aperiam, eaque ipsa Neque.</p>
                                    <div class="calltoaction-button mt-4">
                                        <span class="calltoaction-icon"><i class="flaticon-phone"></i></span>
                                        <a href="callto://+00812548359874">+008 12548 359 874</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--// Call To Action Area -->
    
            </main>
            <!-- //Page Conent -->
    
            <!-- Footer Area -->
            <footer id="footer" class="footer-area fixed--footer">
    
                <!-- Footer Widgets Area -->
                <div class="footer-area__widgets section-padding--lg bg--dark--light">
                    <div class="container">
                        <div class="widget-area footer--widgets">
    
                            <!-- Single Widget -->
                            <div class="widget widget-about">
                                <div class="footer-area__logo">
                                    <a href="index.html">
                                        <img src="../images/logo/logo-footer.png" alt="footer logo">
                                    </a>
                                </div>
                                <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium oloremque laudantium, totam rem
                                    onsectetur sires
                                    to obtain pain of itself because</p>
                                <div class="social-icons social-icons--rounded">
                                    <ul>
                                        <li class="facebook">
                                            <a href="https://www.facebook.com/">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li class="twitter">
                                            <a href="https://twitter.com/">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li class="instagram">
                                            <a href="https://www.instagram.com/">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li class="google-plus">
                                            <a href="https://plus.google.com/discover">
                                                <i class="fa fa-google-plus"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!--// Single Widget -->
    
                            <!-- Single Widget -->
                            <div class="widget widget-quick-links">
                                <h5 class="widget-title">QUICK LINKS</h5>
                                <ul>
                                    <li>
                                        <a href="services.html">Our Services</a>
                                    </li>
                                    <li>
                                        <a href="features.html">Features</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <li>
                                        <a href="#">Help Centre</a>
                                    </li>
                                    <li>
                                        <a href="contact.html">Contact Us</a>
                                    </li>
                                </ul>
                            </div>
                            <!--// Single Widget -->
    
                            <!-- Single Widget -->
                            <div class="widget widget-twitter-feed">
                                <h5 class="widget-title">Twitter Feed</h5>
                                <ul>
                                    <li>
                                        <p>
                                            <a href="">@Alex Smith</a>, unde omnis te us error sit voluptatem</p>
                                        <span class="time">
                                            <a href="#">10 Mins ago</a>
                                        </span>
                                    </li>
                                    <li>
                                        <p>
                                            <a href="">@Justin Bieber</a>, unde omnis te us error sit voluptatem</p>
                                        <span class="time">
                                            <a href="#">12 Mins ago</a>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                            <!--// Single Widget -->
    
                            <!-- Single Widget -->
                            <div class="widget widget-contact-info">
                                <h5 class="widget-title">Contact Info</h5>
                                <ul>
                                    <li>
                                        <p>256 Notrh Tower, Western City Mid Town, Las Vagas, USA</p>
                                    </li>
                                    <li>
                                        <p>
                                            <a href="callto://+00812568987789">+008 12568 987 789</a>
                                        </p>
                                        <p>
                                            <a href="callto://+00835687567458">+008 35687 567 458</a>
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            <a href="mailto://info@fsulting.com">info@fsulting.com</a>
                                        </p>
                                        <p>
                                            <a href="mailto://info@fsulting.com">www.fsulting.com</a>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                            <!--// Single Widget -->
    
                        </div>
                    </div>
                </div>
                <!--// Footer Widgets Area -->
                <!-- Footer Copyright Area -->
                <div class="footer-area__copyright bg--dark">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="copyright text-center">
                                    ©COPYRIGHT, ALL RIGHTS RESERVED BY
                                    <a href="#">FSULTING</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--// Footer Copyright Area -->
            </footer>
            <!-- //Footer Area -->
        </div>
        <!-- //Main wrapper -->
<style>
    .popover_content_wrapper a{
        color: white !important;
    }
    a:hover{
        text-decoration: none;
    }
    .list-group-item{
        padding: 15% !important;
        text-align:center !important;
        margin-top: 10px !important;
        background: #333982;
        font-size: 18px !important;
        font-weight: bold !important;
    }
#loading
{
	text-align:center; 
	background: url('loader.gif') no-repeat center; 
	height: 150px;
}
.popover
		{
		    width: 100%;
		    max-width: 800px;
        }
        .add_to_cart{
            background: #333982;
			color: white !important;
			
        }
</style>

<script>  
$(document).ready(function(){

	load_product();

	load_cart_data();
    
	function load_product()
	{
		$.ajax({
			url:"fetch_data.php",
			method:"POST",
			success:function(data)
			{
				$('#display_item').html(data);
			}
		});
	}

	function load_cart_data()
	{
		$.ajax({
			url:"fetch_cart.php",
			method:"POST",
			dataType:"json",
			success:function(data)
			{
				$('#cart_details').html(data.cart_details);
				$('.total_price').text(data.total_price);
				$('.badge').text(data.total_item);
			}
		});
	}

	$('#cart-popover').popover({
		html : true,
        container: 'body',
        content:function(){
        	return $('#popover_content_wrapper').html();
        }
	});

	$(document).on('click', '.add_to_cart', function(){
		var product_id = $(this).attr("id");
		var product_name = $('#name'+product_id+'').val();
		var product_price = $('#price'+product_id+'').val();
		var product_quantity = $('#quantity'+product_id).val();
		var action = "add";
		if(product_quantity > 0)
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, product_name:product_name, product_price:product_price, product_quantity:product_quantity, action:action},
				success:function(data)
				{
					load_cart_data();
					alert("Item has been Added into Cart");
				}
			});
		}
		else
		{
			alert("lease Enter Number of Quantity");
		}
	});

	$(document).on('click', '.delete', function(){
		var product_id = $(this).attr("id");
		var action = 'remove';
		if(confirm("Are you sure you want to remove this product?"))
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					$('#cart-popover').popover('hide');
					alert("Item has been removed from Cart");
				}
			})
		}
		else
		{
			return false;
		}
	});

	$(document).on('click', '#clear_cart', function(){
		var action = 'empty';
		$.ajax({
			url:"action.php",
			method:"POST",
			data:{action:action},
			success:function()
			{
				load_cart_data();
				$('#cart-popover').popover('hide');
				alert("Your Cart has been clear");
			}
		});
	});
    
});

</script>
<script>
$(document).ready(function(){
    filter_data();
    function filter_data()
    {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
        // var ram = get_filter('ram');
        // var storage = get_filter('storage');
        $.ajax({
            url:"fetch_data.php",
            method:"POST",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price,
             brand:brand},
            success:function(data){
                $('.filter_data').html(data);
            }
        });
    }
    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }
    $('.common_selector').click(function(){
        filter_data();
    });
    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });
});
</script>
 <!-- JS Files -->
        <script src="../js/popper.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/active.js"></script><a id="scrollUp" href="#top" style="position: fixed; z-index: 2147483647;"><i class="fa fa-angle-up"></i></a>
        <script src="../js/scripts.js"></script>
</body>

</html>
