<?php
				if($statement->execute())
				{
					$result = $statement->fetchAll();
					$output = '';

					// var_dump($result);

					foreach($result as $key => $row)
					{
						$blockClass = "about-block";
						$leftImg    = '';
						$rightImg   = '';
						if( ($key % 2) == 0 ){
							$blockClass = "about-block-snd";
							$rightImg   = '
								<div class="changer-right wow bounceInRight" data-wow-delay="0.1s">
									<img src="'.$row["image"].'" style=" box-shadow: 10px 10px 12px grey;">
								</div>
							';
							$imgPositionClass = 'changer-left wow bounceInLeft';
						}
						else{
							$leftImg    = '
								<div class="changer-left-snd img-space wow bounceInLeft" data-wow-delay="0.1s">
									<img src="'.$row["image"].'" style=" box-shadow: 10px 10px 12px grey;">
								</div> <br>
							';

							$imgPositionClass = 'changer-right-snd wow bounceInRight';
						}

						$output .= '
							<div class="about-main">
								<div class="changer-main">
									<span class="devide-line w3-agile"> </span>
									<div class="'.$blockClass.'">
										'.$leftImg.'
										<div class="'.$imgPositionClass.'" data-wow-delay="0.1s">
											<h3>'.$row["title"].'</h3>
											<h4>'.$row["name"].'</h4>

											'.$row["description"].'
											
											<a href="#paymntBK" rel="modal:open">
												<input type="text" name="quantity" id="quantity' . $row["id"] .'" class="form-control quantity qnty-input" value="1" />
												<button 
													class="pay fa btn btn-danger add_to_cart" 
													name="add_to_cart"
													data-orderId="ID00'.$row["id"].'" 
													data-MYRCode="'.$row["price"] .'" 
													data-serviceTitle="'.$row["title"].'"
													id="'.$row["id"].'"
												>
													Add To Cart &nbsp;&nbsp;&nbsp;	&#xf218 '.$row["price"] .' MYR
												</button>
												
												<input type="hidden" name="hidden_name" id="name'.$row["id"].'" value="'.$row["title"].'" />
												<input type="hidden" name="hidden_price" id="price'.$row["id"].'" value="'.$row["price"] .'" />
											</a>
										</div>
										<!--financial course model end-->
									</div>
									'.$rightImg.'
									<div class="clearfix"> </div>
									<div class="ch-bott1 agile">
										<span class="botted"> </span>
									</div>
								</div>
							</div>
						';
					}

					echo $output;
				}
			?>