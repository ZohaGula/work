<?php

//database_connection.php
// $connect = new PDO("mysql:host=localhost;dbname=sandskha_db", "root", "root");
$connect = new PDO("mysql:host=localhost;dbname=wesmarti_sns_Db", "wesmarti_snsUser", "snskhan@321");

?>
