<?php

echo "RECEIVEOK";