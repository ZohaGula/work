<?php
	echo $_POST['RESULTMSG'];
?>
