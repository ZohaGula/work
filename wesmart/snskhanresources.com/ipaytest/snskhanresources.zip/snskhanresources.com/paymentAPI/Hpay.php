<?php
// echo "<pre>";
// var_dump($_POST);
/*
    MerchantKey = “apple”
    MerchantCode = “M00003”
    RefNo = “A00000001”
    Amount = “1.00” (Note: Remove the “.” and “,” in the string before hash)
    Currency = “MYR”
    The hash would be calculated on the following string:
    appleM00003A00000001100MYR
*/

if( isset($_POST['hpayconfirm']) ){

    $split_amount = str_replace(
        ".", 
        "",
        str_replace(
            ",", 
            '', 
            str_replace("MYR", '', $_POST['amount'])
        ) 
    );
    // echo $split_amount;

    $token      = "mzXikXdxQ8M14621A000000019";
    $currency   = "MYR";
    $signature  = $token.$split_amount.$currency;

    function iPay88_signature($source)
    {
        return base64_encode(hex2bin(sha1($source)));
    }

    if (!function_exists('hex2bin')){
        function hex2bin($hexSource)
        {
            for ($i=0;$i<strlen($hexSource);$i=$i+2)
            {
              $bin .= chr(hexdec(substr($hexSource,$i,2)));
            }
          return $bin;
        }
    }

    echo $generateSignature = iPay88_signature($signature);

    echo '
    <FORM method="post" id="ePayment" name="ePayment" action="https://www.mobile88.com/ePayment/entry.asp">
        <INPUT type="hidden" name="MerchantCode" value="M14621">
        <INPUT type="hidden" name="PaymentId" value="">
        <INPUT type="hidden" name="RefNo" value="A000000019">
        <INPUT type="hidden" name="Amount" value="1.00">
        <INPUT type="hidden" name="Currency" value="MYR">
        <INPUT type="hidden" name="ProdDesc" value="">
        <INPUT type="hidden" name="UserName" value="'.$_POST["​bill_name"].'">
        <INPUT type="hidden" name="UserEmail" value="'.$_POST["​bill_email"].'">
        <INPUT type="hidden" name="UserContact" value="'.$_POST["bill_mobile"].'">
        <INPUT type="hidden" name="Remark" value="">
        <INPUT type="hidden" name="Lang" value="UTF-8">
        <INPUT type="hidden" name="Signature" value="'.$generateSignature.'">
        <INPUT type="hidden" name="ResponseURL" value="http://ipaytest.snskhanresources.com/response.php">
        <INPUT type="hidden" name="BackendURL" value="http://ipaytest.snskhanresources.com/backend_response.php">
    </FORM>
    <script>
        var form = document.querySelector("#ePayment");
        form.submit();
    </script>
    ';
}
else{
    header("Location:../index.php");
}