<h1>Buyer cancel the payment!</h1>

<?php if (isset($_GET['token'])) { ?>
    <p>Token: <?php echo $_GET['token']; ?></p>
<?php } ?>