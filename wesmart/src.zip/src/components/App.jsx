import React from 'react';
import logo from './quiz/download.png'
import BoxScore from './quiz/BoxScore.jsx';
import QuestionList from './quiz/QuestionList.jsx';
import Results from './quiz/Results.jsx';
import Home from '../Home';
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      questions: [
        {
          id: 1,
          text: 'What does JSON stand for',
          choices: [
            {
              id: 'a',
              text: 'JavaScript Oriented Notation',
            },
            {
              id: 'b',
              text: 'JavaScript Object Notation',
            },
            {
              id: 'c',
              text: 'JavaScript Organic Notation',
            }
          ],
          correct: 'b'
        },
        {
          id: 2,
          text: 'Which company mantains ReactJS',
          choices: [
            {
              id: 'a',
              text: 'Google',
            },
            {
              id: 'b',
              text: 'Facebook',
            },
            {
              id: 'c',
              text: 'Airbnb',
            }
          ],
          correct: 'b'
        },
        {
          id: 3,
          text: 'Is it an antipattern to include props in the getInitialState method of a component?',
          choices: [
            {
              id: 'a',
              text: 'Yes',
            },
            {
              id: 'b',
              text: 'No',
            },
          ],
          correct: 'a'
        },
        {
          id: 4,
          text: 'Is ReactJS a framework by itself?',
          choices: [
            {
              id: 'a',
              text: 'Yes',
            },
            {
              id: 'b',
              text: 'No',
            },
          ],
          correct: 'b'
        },
        {
          id:5,
          text :'Reactjs is Framework of ?',
          choices:[
            {
              id: 'a',
              text : 'jQuery'
            },
            {
              id:'b',
              text: 'Bootstrap',
            },
            {
              id : 'c',
              text : 'Javascript',
            },
          ],
          correct : 'c'
        },
        {
          id:6,
          text:'Javascript can talk to server',
          choices:[
            {
            id: 'a',
            text : 'True',
            },
            {
              id:'b',
              text : 'False',
            },
            {
              id: 'c',
              text : 'Some time it can'
            }
          ],
          correct : 'b'
        },
      ],
      score: 0,
      current: 1
    }
  }
  setCurrent(current) {
    this.setState({current});
  }
  setScore(score) {
    this.setState({score});
  }
  render() {
    if (this.state.current > this.state.questions.length) {
      var boxscore = '';
      var results = <Results {...this.state}/>
    } else {
      var boxscore = <BoxScore {...this.state} />
      var results = '';
    }
    return (
      <div>
        <div className="well"><Home /></div>
        {boxscore}
        <QuestionList setScore={this.setScore.bind(this)} setCurrent={this.setCurrent.bind(this)} {...this.state}/>
        {results}
      </div>

    );
  }
}

export default App;
