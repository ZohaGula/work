import React from 'react';
import logo from './download.png'
import fire from '../../config/Fire';
class Results extends React.Component {
  render() {
    var percent = (this.props.score / this.props.questions.length * 100);
    if (percent > 80) {
      var message =  fire.auth().currentUser.displayName + ' ' +' You did awesome!' ;
    } else if (percent < 80 && percent > 60) {
      var message = 'You did just fine';
    } else {
      var message = 'You did horrible, sorry';
    }
    return (
      <div className="header  text-center"><img src={logo} alt="logo" width="200" height="150"/>
        <h4 className="score">You got <span className="score">{this.props.score}</span> out of <span className="score">{this.props.questions.length}</span></h4>
        <h2>{percent}% - {message}</h2>
        <a className="btn btn-info " href="./">Take test again</a>
      </div>
    );
  }
}

export default Results;
