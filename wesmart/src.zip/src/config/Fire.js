import firebase from 'firebase';
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyAMheoGRgZACfMFN1paLPjfV6tsqoqqFGo",
    authDomain: "quiz-22388.firebaseapp.com",
    databaseURL: "https://quiz-22388.firebaseio.com",
    projectId: "quiz-22388",
    storageBucket: "quiz-22388.appspot.com",
    messagingSenderId: "131029656647"
  };
 
export default firebase.initializeApp(config);
