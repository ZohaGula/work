import React, { Component } from 'react';
import fire from './config/Fire';

class Home extends Component {
    reset(e){
     this.state={ emailAddress :ReactDOM.findDOMNode(this.refs.email)}
     console.log(this.state.emailAddress)
        var auth = fire.auth();
       
        
        auth.sendPasswordResetEmail(this.state.emailAddress).then(function() {
          alert("Email sent")
            }).catch(function(error) {
                alert("Email failed")
        });
    }
   

    render(e) {
 

        return (
            <div>
<input type="text" className="form-control" placeholder="Rest your password" onClick={this.reset}  ref='email'/>
            </div>
        );

    }

}

export default Home;

